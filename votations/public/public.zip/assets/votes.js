
const app = {
    data() {
        return {
            nbCandidats: 10
        }
    },
    async mounted() {

    },
    computed: {

    },
    methods: {

    }
}

Vue.createApp(app).mount('#app');